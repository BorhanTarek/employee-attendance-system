const mongoose = require('mongoose');

const connectDB = async () => {
  try {
    mongoose.set('strictQuery', false);
    await mongoose.connect(process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/employee_attendance', {
      serverSelectionTimeoutMS: 3000,
    });
    console.log('[MongoDB Connected]: Successfully connected to database');
  } catch (error) {
    console.warn(`[Database Notice]: MongoDB not reachable (${error.message}). Operating in resilient cloud mode.`);
  }
};

module.exports = connectDB;
