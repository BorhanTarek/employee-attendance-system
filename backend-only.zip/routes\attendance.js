const express = require('express');
const router = express.Router();
const Attendance = require('../models/Attendance');
const memoryStore = require('../utils/memoryStore');
const { protect, adminOnly } = require('../middleware/auth');
const { calculateDistance } = require('../utils/geofence');

const TARGET_LAT = parseFloat(process.env.TARGET_LAT || '37.7749');
const TARGET_LNG = parseFloat(process.env.TARGET_LNG || '-122.4194');
const ALLOWED_RADIUS = parseFloat(process.env.ALLOWED_RADIUS || '50');

router.get('/config', protect, (req, res) => {
  return res.json({
    targetLat: TARGET_LAT,
    targetLng: TARGET_LNG,
    allowedRadius: ALLOWED_RADIUS,
  });
});

router.post('/check-in', protect, async (req, res) => {
  const { latitude, longitude } = req.body;

  if (latitude === undefined || longitude === undefined) {
    return res.status(400).json({ message: 'GPS coordinates (latitude, longitude) are required' });
  }

  const distance = calculateDistance(latitude, longitude, TARGET_LAT, TARGET_LNG);
  const isInBounds = distance <= ALLOWED_RADIUS;

  if (!isInBounds) {
    try {
      await Attendance.create({
        user: req.user._id,
        type: 'check-in',
        location: { latitude, longitude },
        distanceFromTarget: Math.round(distance * 10) / 10,
        status: 'rejected',
      });
    } catch (err) {
      await memoryStore.addAttendanceRecord({
        userId: req.user._id,
        type: 'check-in',
        latitude,
        longitude,
        distance: Math.round(distance * 10) / 10,
        status: 'rejected',
      });
    }

    return res.status(400).json({
      message: `Check-in denied. You are ${Math.round(distance)}m away from the office. Allowed radius is ${ALLOWED_RADIUS}m.`,
      distance: Math.round(distance),
      allowedRadius: ALLOWED_RADIUS,
      isInBounds: false,
    });
  }

  let record;
  try {
    record = await Attendance.create({
      user: req.user._id,
      type: 'check-in',
      location: { latitude, longitude },
      distanceFromTarget: Math.round(distance * 10) / 10,
      status: 'success',
    });
  } catch (err) {
    record = await memoryStore.addAttendanceRecord({
      userId: req.user._id,
      type: 'check-in',
      latitude,
      longitude,
      distance: Math.round(distance * 10) / 10,
      status: 'success',
    });
  }

  return res.status(201).json({
    message: 'Check-in successful! Have a great workday.',
    record,
    distance: Math.round(distance),
    isInBounds: true,
  });
});

router.post('/check-out', protect, async (req, res) => {
  const { latitude, longitude } = req.body;

  if (latitude === undefined || longitude === undefined) {
    return res.status(400).json({ message: 'GPS coordinates (latitude, longitude) are required' });
  }

  const distance = calculateDistance(latitude, longitude, TARGET_LAT, TARGET_LNG);
  const isInBounds = distance <= ALLOWED_RADIUS;

  if (!isInBounds) {
    try {
      await Attendance.create({
        user: req.user._id,
        type: 'check-out',
        location: { latitude, longitude },
        distanceFromTarget: Math.round(distance * 10) / 10,
        status: 'rejected',
      });
    } catch (err) {
      await memoryStore.addAttendanceRecord({
        userId: req.user._id,
        type: 'check-out',
        latitude,
        longitude,
        distance: Math.round(distance * 10) / 10,
        status: 'rejected',
      });
    }

    return res.status(400).json({
      message: `Check-out denied. You are ${Math.round(distance)}m away from the office. Allowed radius is ${ALLOWED_RADIUS}m.`,
      distance: Math.round(distance),
      allowedRadius: ALLOWED_RADIUS,
      isInBounds: false,
    });
  }

  let record;
  try {
    record = await Attendance.create({
      user: req.user._id,
      type: 'check-out',
      location: { latitude, longitude },
      distanceFromTarget: Math.round(distance * 10) / 10,
      status: 'success',
    });
  } catch (err) {
    record = await memoryStore.addAttendanceRecord({
      userId: req.user._id,
      type: 'check-out',
      latitude,
      longitude,
      distance: Math.round(distance * 10) / 10,
      status: 'success',
    });
  }

  return res.status(201).json({
    message: 'Check-out successful! See you tomorrow.',
    record,
    distance: Math.round(distance),
    isInBounds: true,
  });
});

router.get('/my-status', protect, async (req, res) => {
  try {
    let todayRecords = [];
    try {
      const startOfDay = new Date();
      startOfDay.setHours(0, 0, 0, 0);

      const endOfDay = new Date();
      endOfDay.setHours(23, 59, 59, 999);

      todayRecords = await Attendance.find({
        user: req.user._id,
        timestamp: { $gte: startOfDay, $lte: endOfDay },
        status: 'success',
      }).sort({ timestamp: -1 });
    } catch (err) {
      todayRecords = memoryStore.memoryAttendance.filter(
        (a) => a.user.toString() === req.user._id.toString() && a.status === 'success'
      );
    }

    const latestPunch = todayRecords[0] || null;

    return res.json({
      latestPunch,
      isCheckedIn: latestPunch ? latestPunch.type === 'check-in' : false,
      todayRecords,
    });
  } catch (error) {
    console.error('Error fetching my-status:', error);
    return res.status(500).json({ message: 'Error fetching today status' });
  }
});

router.get('/logs', protect, adminOnly, async (req, res) => {
  try {
    let logs = [];
    try {
      logs = await Attendance.find()
        .populate('user', 'name email employeeId role')
        .sort({ timestamp: -1 });
    } catch (err) {
      logs = memoryStore.memoryAttendance.map((a) => {
        const u = memoryStore.memoryUsers.find((user) => user._id.toString() === a.user.toString());
        return { ...a, user: u };
      });
    }

    return res.json(logs);
  } catch (error) {
    console.error('Error fetching logs:', error);
    return res.status(500).json({ message: 'Server error fetching attendance logs' });
  }
});

module.exports = router;
