const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const memoryStore = require('../utils/memoryStore');
const { protect } = require('../middleware/auth');

const generateToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET || 'supersecretjwtkey_12345!', {
    expiresIn: '30d',
  });
};

router.post('/login', async (req, res) => {
  const { loginIdentifier, password } = req.body;

  if (!loginIdentifier || !password) {
    return res.status(400).json({ message: 'Please provide Email/Employee ID and Password' });
  }

  try {
    let user = null;

    // 1. Try finding in MongoDB
    try {
      user = await User.findOne({
        $or: [
          { email: loginIdentifier.toLowerCase() },
          { employeeId: loginIdentifier },
        ],
      });
    } catch (dbErr) {
      console.warn('MongoDB lookup failed, attempting memory fallback:', dbErr.message);
    }

    // 2. Fallback to memory store if DB is offline or user not found in DB
    if (!user) {
      user = await memoryStore.findUserByIdentifier(loginIdentifier);
    }

    if (!user) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    return res.json({
      _id: user._id,
      name: user.name,
      email: user.email,
      employeeId: user.employeeId,
      role: user.role,
      token: generateToken(user._id),
    });
  } catch (error) {
    console.error('Login error:', error);
    return res.status(500).json({ message: 'Server error during login' });
  }
});

router.get('/me', protect, async (req, res) => {
  return res.json(req.user);
});

module.exports = router;
