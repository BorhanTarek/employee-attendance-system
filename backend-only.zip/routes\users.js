const express = require('express');
const router = express.Router();
const User = require('../models/User');
const memoryStore = require('../utils/memoryStore');
const { protect, adminOnly } = require('../middleware/auth');

router.post('/create', protect, adminOnly, async (req, res) => {
  const { name, email, employeeId, password, role } = req.body;

  if (!name || !email || !employeeId || !password) {
    return res.status(400).json({ message: 'All fields (name, email, employeeId, password) are required' });
  }

  try {
    let newUser = null;

    try {
      const userExists = await User.findOne({
        $or: [{ email: email.toLowerCase() }, { employeeId }],
      });

      if (userExists) {
        return res.status(400).json({ message: 'User with this Email or Employee ID already exists' });
      }

      newUser = new User({
        name,
        email: email.toLowerCase(),
        employeeId,
        password,
        role: role || 'Employee',
      });
      await newUser.save();
    } catch (dbErr) {
      // Memory Store Fallback
      newUser = await memoryStore.addUser({ name, email, employeeId, password, role });
    }

    return res.status(201).json({
      message: 'Employee account created successfully',
      user: {
        _id: newUser._id,
        name: newUser.name,
        email: newUser.email,
        employeeId: newUser.employeeId,
        role: newUser.role,
        createdAt: newUser.createdAt,
      },
    });
  } catch (error) {
    console.error('Error creating user:', error);
    return res.status(500).json({ message: 'Server error creating user' });
  }
});

router.get('/list', protect, adminOnly, async (req, res) => {
  try {
    let users = [];
    try {
      users = await User.find().select('-password').sort({ createdAt: -1 });
    } catch (err) {
      users = memoryStore.memoryUsers;
    }
    return res.json(users);
  } catch (error) {
    console.error('Error fetching users:', error);
    return res.status(500).json({ message: 'Server error fetching user list' });
  }
});

router.delete('/:id', protect, adminOnly, async (req, res) => {
  try {
    try {
      await User.findByIdAndDelete(req.params.id);
    } catch (err) {
      const idx = memoryStore.memoryUsers.findIndex((u) => u._id.toString() === req.params.id);
      if (idx !== -1) memoryStore.memoryUsers.splice(idx, 1);
    }
    return res.json({ message: 'Employee deleted successfully' });
  } catch (error) {
    console.error('Error deleting user:', error);
    return res.status(500).json({ message: 'Server error deleting user' });
  }
});

module.exports = router;
