const bcrypt = require('bcryptjs');

// In-memory mock store for cloud environments without active MongoDB
const memoryUsers = [];
const memoryAttendance = [];

// Seed default Admin in memory
(async () => {
  const hashedPassword = await bcrypt.hash('adminpassword123', 10);
  memoryUsers.push({
    _id: 'admin_mem_id_001',
    name: 'System Admin',
    email: 'admin@company.com',
    employeeId: 'ADMIN001',
    password: hashedPassword,
    role: 'Admin',
    createdAt: new Date(),
    comparePassword: async function (candidate) {
      return bcrypt.compare(candidate, this.password);
    },
  });
})();

module.exports = {
  memoryUsers,
  memoryAttendance,
  findUserByIdentifier: async (identifier) => {
    const idLower = identifier.toLowerCase();
    return memoryUsers.find(
      (u) => u.email.toLowerCase() === idLower || u.employeeId === identifier
    );
  },
  findUserById: async (id) => {
    return memoryUsers.find((u) => u._id.toString() === id.toString());
  },
  addUser: async ({ name, email, employeeId, password, role }) => {
    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = {
      _id: 'user_mem_' + Date.now(),
      name,
      email: email.toLowerCase(),
      employeeId,
      password: hashedPassword,
      role: role || 'Employee',
      createdAt: new Date(),
      comparePassword: async function (candidate) {
        return bcrypt.compare(candidate, this.password);
      },
    };
    memoryUsers.push(newUser);
    return newUser;
  },
  addAttendanceRecord: async ({ userId, type, latitude, longitude, distance, status }) => {
    const record = {
      _id: 'att_mem_' + Date.now(),
      user: userId,
      type,
      location: { latitude, longitude },
      distanceFromTarget: distance,
      status,
      timestamp: new Date(),
    };
    memoryAttendance.push(record);
    return record;
  },
};
