# Employee Attendance System (GeoAttend)

A full-stack Employee Attendance Management solution featuring dual-layer GPS Geofencing validation, an Admin Web Dashboard, and a React Native Employee Mobile App. Inspired by the visual identity of **RATP Dev**.

---

## 🎨 Visual Design & Tech Stack

- **Design System**: RATP Dev Palette — Deep Navy Teal (`#04141c`), RATP Transit Cyan (`#009AA6`), Mint Green (`#00C897`), pill geometry.
- **Backend API**: Node.js, Express, MongoDB (Mongoose), JSON Web Tokens (JWT), Haversine formula geofence module.
- **Admin Web App**: React.js, Vite, custom dark-glass CSS styling system.
- **Employee Mobile App**: React Native, Expo, `expo-location` foreground GPS tracking, `AsyncStorage`.

---

## 📁 Repository Structure

```text
├── backend/                  # REST API Service (Deployable to Render)
│   ├── config/db.js          # MongoDB connection
│   ├── models/               # User & Attendance schemas
│   ├── routes/               # Auth, User Management & Geofenced Attendance routes
│   ├── utils/geofence.js     # Haversine distance algorithm
│   ├── middleware/auth.js    # JWT & Admin role verification
│   ├── render.yaml           # Render deployment configuration
│   └── server.js             # API entry point & Admin seed
├── web/                      # Admin Web Portal (React + Vite)
│   ├── src/
│   │   ├── context/          # Auth Context & Session handling
│   │   ├── pages/            # Login & Admin Dashboard screens
│   │   └── index.css         # RATP Dev design system
├── mobile/                   # Employee Mobile App (React Native Expo)
│   ├── src/
│   │   ├── screens/          # LoginScreen & Geofenced DashboardScreen
│   │   └── services/         # API integration & distance math
```

---

## 🔒 Geofencing Architecture

1. **Target Geofence**: Hardcoded/configurable target coordinates (default `TARGET_LAT = 37.7749`, `TARGET_LNG = -122.4194`) and `ALLOWED_RADIUS = 50` meters.
2. **Client Validation**: Mobile app continuously computes distance to office. If distance $> 50\text{m}$, the punch button is disabled.
3. **Server Validation**: Backend re-validates raw coordinates upon every request using the Haversine formula and rejects punches if distance $> 50\text{m}$ (HTTP 400).

---

## 🚀 Deployment Instructions (Render)

1. Create a new repository on GitHub and upload the files.
2. Log into [Render.com](https://render.com/) and create a **Web Service**.
3. Select your repository and set **Root Directory** to `backend`.
4. Build Command: `npm install` | Start Command: `node server.js`.
5. Add Environment Variables: `MONGO_URI`, `JWT_SECRET`, `TARGET_LAT`, `TARGET_LNG`, `ALLOWED_RADIUS`.
