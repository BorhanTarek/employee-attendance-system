import React, { useState, useEffect } from 'react';
import { StyleSheet, View, Text, ActivityIndicator } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import AsyncStorage from '@react-native-async-storage/async-storage';
import LoginScreen from './src/screens/LoginScreen';
import DashboardScreen from './src/screens/DashboardScreen';
import { api } from './src/services/api';

export default function App() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    checkExistingSession();
  }, []);

  const checkExistingSession = async () => {
    try {
      const savedUserData = await AsyncStorage.getItem('userData');
      const token = await AsyncStorage.getItem('userToken');

      if (savedUserData && token) {
        setUser(JSON.parse(savedUserData));
      }
    } catch (e) {
      console.error('Failed to load storage session', e);
    } finally {
      setLoading(false);
    }
  };

  const handleLoginSuccess = (userData) => {
    setUser(userData);
  };

  const handleLogout = async () => {
    await api.logout();
    setUser(null);
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#00c897" />
        <Text style={styles.loadingText}>Initializing RATP Dev GeoAttend...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      {user ? (
        <DashboardScreen user={user} onLogout={handleLogout} />
      ) : (
        <LoginScreen onLoginSuccess={handleLoginSuccess} />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#04141c',
  },
  loadingContainer: {
    flex: 1,
    backgroundColor: '#04141c',
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: '#8caab5',
    marginTop: 12,
    fontSize: 14,
    fontWeight: '600',
  },
});
