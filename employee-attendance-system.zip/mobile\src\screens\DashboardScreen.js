import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  ScrollView,
  SafeAreaView,
} from 'react-native';
import * as Location from 'expo-location';
import { api } from '../services/api';
import { calculateDistance } from '../utils/geofence';

// Default Fallback Office Location
const DEFAULT_TARGET_LAT = 37.7749;
const DEFAULT_TARGET_LNG = -122.4194;
const DEFAULT_ALLOWED_RADIUS = 50;

export default function DashboardScreen({ user, onLogout }) {
  const [currentTime, setCurrentTime] = useState(new Date().toLocaleTimeString());
  const [locationPermissionGranted, setLocationPermissionGranted] = useState(null);
  const [currentLocation, setCurrentLocation] = useState(null);
  const [distance, setDistance] = useState(null);
  const [isInBounds, setIsInBounds] = useState(false);
  const [isCheckedIn, setIsCheckedIn] = useState(false);
  const [loadingAction, setLoadingAction] = useState(false);
  const [refreshingLocation, setRefreshingLocation] = useState(false);

  // Config parameters loaded from backend
  const [targetLat, setTargetLat] = useState(DEFAULT_TARGET_LAT);
  const [targetLng, setTargetLng] = useState(DEFAULT_TARGET_LNG);
  const [allowedRadius, setAllowedRadius] = useState(DEFAULT_ALLOWED_RADIUS);

  // 1. Live Clock
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date().toLocaleTimeString());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // 2. Request Permissions & Load Data on Startup
  useEffect(() => {
    initDashboard();
  }, []);

  const initDashboard = async () => {
    await loadBackendConfig();
    await checkMyStatus();
    await requestLocationPermission();
  };

  const loadBackendConfig = async () => {
    try {
      const cfg = await api.getConfig();
      if (cfg.targetLat) setTargetLat(cfg.targetLat);
      if (cfg.targetLng) setTargetLng(cfg.targetLng);
      if (cfg.allowedRadius) setAllowedRadius(cfg.allowedRadius);
    } catch (err) {
      console.log('Using default geofence configuration');
    }
  };

  const checkMyStatus = async () => {
    try {
      const status = await api.getMyStatus();
      setIsCheckedIn(status.isCheckedIn);
    } catch (err) {
      console.error('Failed to fetch status:', err);
    }
  };

  const requestLocationPermission = async () => {
    setRefreshingLocation(true);
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        setLocationPermissionGranted(false);
        setRefreshingLocation(false);
        return;
      }
      setLocationPermissionGranted(true);
      await updateGPSPosition();
    } catch (err) {
      console.error('Error requesting location permission:', err);
      setLocationPermissionGranted(false);
    } finally {
      setRefreshingLocation(false);
    }
  };

  const updateGPSPosition = async () => {
    setRefreshingLocation(true);
    try {
      const loc = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.High,
      });

      const { latitude, longitude } = loc.coords;
      setCurrentLocation({ latitude, longitude });

      // Compute distance to office
      const computedDist = calculateDistance(
        latitude,
        longitude,
        targetLat,
        targetLng
      );
      const roundedDist = Math.round(computedDist);
      setDistance(roundedDist);

      const boundsCheck = roundedDist <= allowedRadius;
      setIsInBounds(boundsCheck);
    } catch (err) {
      Alert.alert('GPS Error', 'Could not obtain your precise current position.');
    } finally {
      setRefreshingLocation(false);
    }
  };

  const handlePunch = async () => {
    if (!currentLocation) {
      Alert.alert('Location Error', 'Current GPS location not available.');
      return;
    }

    if (!isInBounds) {
      Alert.alert('Outside Office Geofence', 'You must be at the office to check in or check out.');
      return;
    }

    setLoadingAction(true);
    try {
      if (isCheckedIn) {
        // Perform Check-Out
        const res = await api.checkOut(
          currentLocation.latitude,
          currentLocation.longitude
        );
        Alert.alert('Checked Out', res.message);
        setIsCheckedIn(false);
      } else {
        // Perform Check-In
        const res = await api.checkIn(
          currentLocation.latitude,
          currentLocation.longitude
        );
        Alert.alert('Checked In', res.message);
        setIsCheckedIn(true);
      }
    } catch (err) {
      Alert.alert('Punch Failed', err.message || 'Server rejected check-in.');
    } finally {
      setLoadingAction(false);
    }
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.container}>
        {/* Profile Banner */}
        <View style={styles.header}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
            <View style={styles.logoBadge}>
              <Text style={styles.logoText}>RATP</Text>
            </View>
            <View>
              <Text style={styles.welcomeText}>RATP Dev Employee</Text>
              <Text style={styles.userName}>{user.name}</Text>
              <Text style={styles.employeeId}>ID: {user.employeeId}</Text>
            </View>
          </View>
          <TouchableOpacity style={styles.logoutBtn} onPress={onLogout}>
            <Text style={styles.logoutText}>Sign Out</Text>
          </TouchableOpacity>
        </View>

        {/* Live Clock Card */}
        <View style={styles.clockCard}>
          <Text style={styles.clockLabel}>SYSTEM TIME</Text>
          <Text style={styles.clockText}>{currentTime}</Text>
          <Text style={styles.dateText}>{new Date().toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</Text>
        </View>

        {/* Location Permission Denied Warning */}
        {locationPermissionGranted === false && (
          <View style={[styles.card, styles.alertCard]}>
            <Text style={styles.alertTitle}>⚠️ Location Permission Required</Text>
            <Text style={styles.alertText}>
              GeoAttend requires foreground GPS access to verify you are at the office. Please enable location permissions in your device settings.
            </Text>
            <TouchableOpacity style={styles.retryBtn} onPress={requestLocationPermission}>
              <Text style={styles.retryBtnText}>Grant Location Permission</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* Geofence Status Card */}
        {locationPermissionGranted && (
          <View style={styles.card}>
            <View style={styles.statusRow}>
              <Text style={styles.cardTitle}>Location Compliance</Text>
              <TouchableOpacity onPress={updateGPSPosition} disabled={refreshingLocation}>
                <Text style={styles.refreshLink}>
                  {refreshingLocation ? 'Updating GPS...' : '🔄 Refresh GPS'}
                </Text>
              </TouchableOpacity>
            </View>

            <View style={styles.badgeContainer}>
              <View
                style={[
                  styles.statusBadge,
                  isInBounds ? styles.badgeSuccess : styles.badgeDanger,
                ]}
              >
                <Text style={styles.badgeText}>
                  {isInBounds ? '✓ In Office Bounds' : '✕ Outside Geofence'}
                </Text>
              </View>
            </View>

            {distance !== null && (
              <Text style={styles.distanceText}>
                Distance from Office: <Text style={{ color: '#00c897', fontWeight: 'bold' }}>{distance} meters</Text> (Allowed: {allowedRadius}m)
              </Text>
            )}

            {!isInBounds && (
              <Text style={styles.warningMessage}>
                "You must be at the office to check in."
              </Text>
            )}
          </View>
        )}

        {/* Main Punch Action Button */}
        <View style={styles.punchSection}>
          <TouchableOpacity
            style={[
              styles.punchButton,
              !isInBounds || !locationPermissionGranted
                ? styles.punchButtonDisabled
                : isCheckedIn
                ? styles.punchButtonCheckOut
                : styles.punchButtonCheckIn,
            ]}
            onPress={handlePunch}
            disabled={!isInBounds || !locationPermissionGranted || loadingAction}
          >
            {loadingAction ? (
              <ActivityIndicator color="#04141c" size="large" />
            ) : (
              <>
                <Text style={styles.punchButtonTitle}>
                  {isCheckedIn ? 'CHECK OUT' : 'CHECK IN'}
                </Text>
                <Text style={styles.punchButtonSubtitle}>
                  {!isInBounds
                    ? 'Out of Office Bounds'
                    : isCheckedIn
                    ? 'Tap to end shift'
                    : 'Tap to start shift'}
                </Text>
              </>
            )}
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#04141c',
  },
  container: {
    padding: 20,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
    marginTop: 10,
  },
  logoBadge: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#00c897',
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoText: {
    color: '#04141c',
    fontWeight: '900',
    fontSize: 12,
  },
  welcomeText: {
    color: '#8caab5',
    fontSize: 12,
  },
  userName: {
    color: '#fff',
    fontSize: 20,
    fontWeight: 'bold',
  },
  employeeId: {
    color: '#00c897',
    fontSize: 12,
    fontWeight: '600',
  },
  logoutBtn: {
    backgroundColor: 'rgba(255, 82, 82, 0.15)',
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(255, 82, 82, 0.3)',
  },
  logoutText: {
    color: '#ff5252',
    fontSize: 12,
    fontWeight: '600',
  },
  clockCard: {
    backgroundColor: '#0a222e',
    borderRadius: 20,
    padding: 24,
    alignItems: 'center',
    marginBottom: 20,
    borderWidth: 1,
    borderColor: 'rgba(0, 154, 166, 0.2)',
  },
  clockLabel: {
    color: '#00c897',
    fontSize: 12,
    fontWeight: 'bold',
    letterSpacing: 1.5,
    marginBottom: 6,
  },
  clockText: {
    color: '#fff',
    fontSize: 34,
    fontWeight: 'bold',
    fontVariant: ['tabular-nums'],
  },
  dateText: {
    color: '#8caab5',
    fontSize: 13,
    marginTop: 4,
  },
  card: {
    backgroundColor: '#0a222e',
    borderRadius: 20,
    padding: 20,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: 'rgba(0, 154, 166, 0.2)',
  },
  alertCard: {
    backgroundColor: 'rgba(255, 82, 82, 0.1)',
    borderColor: 'rgba(255, 82, 82, 0.3)',
  },
  alertTitle: {
    color: '#ff5252',
    fontWeight: 'bold',
    fontSize: 16,
    marginBottom: 6,
  },
  alertText: {
    color: '#fca5a5',
    fontSize: 13,
    lineHeight: 18,
    marginBottom: 12,
  },
  retryBtn: {
    backgroundColor: '#ff5252',
    padding: 10,
    borderRadius: 20,
    alignItems: 'center',
  },
  retryBtnText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 13,
  },
  statusRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  cardTitle: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  refreshLink: {
    color: '#00c897',
    fontSize: 12,
    fontWeight: '600',
  },
  badgeContainer: {
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  statusBadge: {
    paddingHorizontal: 14,
    paddingVertical: 6,
    borderRadius: 20,
  },
  badgeSuccess: {
    backgroundColor: 'rgba(0, 200, 151, 0.2)',
    borderWidth: 1,
    borderColor: '#00c897',
  },
  badgeDanger: {
    backgroundColor: 'rgba(255, 82, 82, 0.2)',
    borderWidth: 1,
    borderColor: '#ff5252',
  },
  badgeText: {
    fontWeight: 'bold',
    fontSize: 13,
    color: '#fff',
  },
  distanceText: {
    color: '#8caab5',
    fontSize: 13,
  },
  warningMessage: {
    color: '#ffb703',
    fontSize: 13,
    fontWeight: '500',
    marginTop: 10,
    fontStyle: 'italic',
  },
  punchSection: {
    marginTop: 10,
    alignItems: 'center',
  },
  punchButton: {
    width: '100%',
    height: 120,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
  },
  punchButtonCheckIn: {
    backgroundColor: '#00c897',
  },
  punchButtonCheckOut: {
    backgroundColor: '#009aa6',
  },
  punchButtonDisabled: {
    backgroundColor: '#102e3c',
    opacity: 0.6,
  },
  punchButtonTitle: {
    color: '#04141c',
    fontSize: 26,
    fontWeight: 'bold',
    letterSpacing: 1,
  },
  punchButtonSubtitle: {
    color: 'rgba(4, 20, 28, 0.8)',
    fontSize: 13,
    marginTop: 4,
    fontWeight: '600',
  },
});
