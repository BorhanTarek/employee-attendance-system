import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { api } from '../services/api';

export default function LoginScreen({ onLoginSuccess }) {
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    if (!identifier || !password) {
      Alert.alert('Required Fields', 'Please enter your Employee ID / Email and password.');
      return;
    }

    setLoading(true);
    try {
      const user = await api.login(identifier, password);
      onLoginSuccess(user);
    } catch (err) {
      Alert.alert('Authentication Failed', err.message || 'Invalid credentials');
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}
    >
      <View style={styles.card}>
        <View style={styles.logoBadge}>
          <Text style={styles.logoText}>RATP</Text>
        </View>
        <Text style={styles.title}>GeoAttend</Text>
        <Text style={styles.subtitle}>RATP Dev Workforce Operations</Text>

        <View style={styles.inputContainer}>
          <Text style={styles.label}>Employee ID or Email</Text>
          <TextInput
            style={styles.input}
            value={identifier}
            onChangeText={setIdentifier}
            placeholder="e.g. EMP101 or jean@ratpdev.com"
            placeholderTextColor="#587987"
            autoCapitalize="none"
          />
        </View>

        <View style={styles.inputContainer}>
          <Text style={styles.label}>Password</Text>
          <TextInput
            style={styles.input}
            value={password}
            onChangeText={setPassword}
            placeholder="••••••••"
            placeholderTextColor="#587987"
            secureTextEntry
          />
        </View>

        <TouchableOpacity
          style={styles.button}
          onPress={handleLogin}
          disabled={loading}
        >
          {loading ? (
            <ActivityIndicator color="#04141c" />
          ) : (
            <Text style={styles.buttonText}>Log In</Text>
          )}
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#04141c',
    justifyContent: 'center',
    padding: 24,
  },
  card: {
    backgroundColor: '#0a222e',
    borderRadius: 24,
    padding: 28,
    borderWidth: 1,
    borderColor: 'rgba(0, 154, 166, 0.2)',
  },
  logoBadge: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#00c897',
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'center',
    marginBottom: 12,
  },
  logoText: {
    color: '#04141c',
    fontWeight: '900',
    fontSize: 14,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 13,
    color: '#8caab5',
    textAlign: 'center',
    marginBottom: 28,
    marginTop: 4,
  },
  inputContainer: {
    marginBottom: 18,
  },
  label: {
    color: '#8caab5',
    fontSize: 13,
    marginBottom: 6,
    fontWeight: '600',
  },
  input: {
    backgroundColor: '#102e3c',
    borderWidth: 1,
    borderColor: 'rgba(0, 154, 166, 0.25)',
    borderRadius: 12,
    padding: 14,
    color: '#fff',
    fontSize: 15,
  },
  button: {
    backgroundColor: '#00c897',
    borderRadius: 30,
    padding: 16,
    alignItems: 'center',
    marginTop: 10,
    boxShadow: '0 4px 16px rgba(0, 200, 151, 0.4)',
  },
  buttonText: {
    color: '#04141c',
    fontWeight: 'bold',
    fontSize: 16,
  },
});
