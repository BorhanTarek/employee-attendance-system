import AsyncStorage from '@react-native-async-storage/async-storage';

// Replace with your local machine's IP address if testing on a physical mobile device (e.g. 'http://192.168.1.50:5000/api')
const BASE_URL = 'http://localhost:5000/api';

async function request(endpoint, options = {}) {
  const token = await AsyncStorage.getItem('userToken');

  const headers = {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...options.headers,
  };

  const response = await fetch(`${BASE_URL}${endpoint}`, {
    ...options,
    headers,
  });

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.message || 'API call failed');
  }

  return data;
}

export const api = {
  login: async (loginIdentifier, password) => {
    const data = await request('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ loginIdentifier, password }),
    });
    if (data.token) {
      await AsyncStorage.setItem('userToken', data.token);
      await AsyncStorage.setItem('userData', JSON.stringify(data));
    }
    return data;
  },

  logout: async () => {
    await AsyncStorage.removeItem('userToken');
    await AsyncStorage.removeItem('userData');
  },

  getConfig: () => request('/attendance/config'),

  getMyStatus: () => request('/attendance/my-status'),

  checkIn: (latitude, longitude) =>
    request('/attendance/check-in', {
      method: 'POST',
      body: JSON.stringify({ latitude, longitude }),
    }),

  checkOut: (latitude, longitude) =>
    request('/attendance/check-out', {
      method: 'POST',
      body: JSON.stringify({ latitude, longitude }),
    }),
};
